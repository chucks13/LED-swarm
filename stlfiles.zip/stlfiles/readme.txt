STL files for LED wand 2.5M LED strip 60 LEDs/M

Proper order:

v-cut-cpu.stl
v-cut185.stl
v-cut185.stl
v-cutspacer.stl
vcut-battery1.stl
vcut-battery2.stl
v-cutspacer.stl
vcut-battery1.stl
vcut-battery2.stl
v-cutspacer.stl
v-cut213.stl
v-cut213.stl
vcut-charger.stl

The battery top are covers for the battery boxes.

I'm not sure about the battery bottoms, but be sure to align them with the spacers so that the wire channel and v-cut spiral both line up.  The wire chanel in the battery boxes, spacers, and tops allow wireing to pass around the battery boxes.

Chucks@he.net
-----------------------------------------------------
The MIT License (MIT)

Copyright (c) 2019 Chuck Sommerville

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.


